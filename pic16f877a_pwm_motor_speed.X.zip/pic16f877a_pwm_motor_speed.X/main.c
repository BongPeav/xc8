/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 20, 2024, 7:22 PM
 */

#include <xc.h>
#include "config.h"
#include "adc.h"

#define _XTAL_FREQ  20000000UL

#define EN1 RC0

/*Fosc = 20MHz Pre-Scaler = 1:16 PWM FREQ = 1.22kHz*/
void pwm1_init(void){
    TRISC2=0;
    CCP1CONbits.CCP1M = 0x0C;
    PR2=0xFF;
    T2CONbits.T2CKPS = 2;
    T2CONbits.TMR2ON = 1;
    /*Set Duty Cycle To 0*/
    CCP1CONbits.CCP1X=0;
    CCP1CONbits.CCP1Y=0;
    CCPR1L=0;
    PIR1bits.TMR2IF = 0;
}

void pwm2_init(void){
    TRISC1 = 0;
    CCP2CONbits.CCP2M = 0x0C;
    PR2 = 0xFF;
    T2CONbits.TOUTPS = 2;
    T2CONbits.TMR2ON = 1;
    /*Set Duty Cycle To 0*/
    CCP2CONbits.CCP2X = 0;
    CCP2CONbits.CCP2Y = 0;
    CCPR2L = 0xFA;
    PIR1bits.TMR2IF = 0;
}

void pwm1_set_duty(uint8_t duty){
    //CCPR1L must less than or equal to PR2
    float f = 1023.0*duty/100; 
    uint16_t duty_cycle = (uint16_t)(f);
    CCPR1L=duty_cycle>>2;
    CCP1CONbits.CCP1X=duty_cycle&0x0002;
    CCP1CONbits.CCP1Y=duty_cycle&0x0001;    
}

void pwm2_set_duty(uint8_t duty){
    //CCPR2L must less than or equal to PR2
    float f = 1023.0*duty/100; 
    uint16_t duty_cycle = (uint16_t)(f);
    CCPR2L=duty_cycle>>2;
    CCP2CONbits.CCP2X=duty_cycle&0x0002;
    CCP2CONbits.CCP2Y=duty_cycle&0x0001;    
}

uint8_t direction = 0;

void main(void) {
    adc_init();
    pwm1_init();
    pwm2_init();
    PORTB = 0;
    TRISB = 0x0F;
    PORTC = 0;
    TRISC = 0;
    RC0 = 1;
    OPTION_REGbits.nRBPU = 0;
    
    while(1){
        uint16_t adc_result = adc_read(0);
        float duty = 100.0*adc_result/1023;
        uint8_t duty_cycle = (uint8_t)(duty);
        if(direction==0){
            pwm1_set_duty(duty_cycle);
            __delay_ms(10);
            pwm2_set_duty(0);
            __delay_ms(100);
        }
        if(direction==1){
            pwm1_set_duty(0);
            __delay_ms(10);
            pwm2_set_duty(duty_cycle);
            __delay_ms(100);
        }
        if(RB0==0) {
            direction = 0;
            RC0 = 0;
            __delay_ms(100);
            RC0 = 1;
        }
        if(RB1==0){
            direction = 1;        
            RC0 = 0;
            __delay_ms(100);
            RC0 = 1;
        }
    }
    return;
}
