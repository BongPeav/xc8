/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 22, 2024, 6:54 PM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  40000000UL

void __interrupt(high_priority) isr(void){
    if(RBIF==1&&RBIE==1){
        
        if(RB7==0) LATB3^=1;
        if(RB6==0) LATB2^=1;
        if(RB5==0) LATB1^=1;
        if(RB4==0) LATB0^=1;
         
        /*
        uint8_t temp = PORTB&0xF0;
        switch(temp){
            case 0x70: LATB3^=1; break;
            case 0xB0: LATB2^=1; break;
            case 0xD0: LATB1^=1; break;
            case 0xE0: LATB0^=1; break;
        }
         */ 
        RBIF=0;
    }
}

void main(void) {
    PORTB = 0;
    LATB = 0;
    TRISB = 0xF0;
    INTCON2bits.nRBPU = 0;
    INTCONbits.RBIF = 0;
    INTCONbits.RBIE = 1;
    INTCONbits.GIE = 1;   
   
    while(1){
        
    }
    return;
}
