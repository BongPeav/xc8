/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 15, 2024, 6:58 PM
 */

#include <xc.h>
#include "config.h"
#include "adc.h"

#define _XTAL_FREQ  20000000UL

#define CS RC2

void spi_init(void){
    /*SPI Mode Clock Low To High*/
    SSPCONbits.CKP=0;
    SSPSTATbits.CKE=1;
    SSPSTATbits.SMP=0;
    /*SPI Master Mode Clock = Fosc/64*/
    SSPCONbits.SSPM=2;
    /*Turn On The Module*/
    SSPCONbits.SSPEN=1;
    SSPSTATbits.BF=1;
    PORTC=0;
    TRISC=0;
    /*SPI SDI Pin Input*/
    TRISC4=1;
}

void spi_send(uint8_t data){
    SSPSTATbits.BF==1;
    SSPBUF=data;
    while(SSPSTATbits.BF==0);
    SSPSTATbits.BF==1;
}

uint8_t spi_receive(void){
    uint8_t data;
    spi_send(0x00);
    data=SSPBUF;
    return data;
}

void main(void) {
    uint16_t adc_result;
    uint16_t data,bar_value;
    spi_init();
    adc_init();
    TRISA=0x01;
    while(1){
        adc_result = adc_read(0);
        data = (adc_result*8)/1023;
        for(char i=0;i<data;i++) bar_value|=(1<<i);
        spi_send(bar_value);
        CS=1;
        CS=0;
        bar_value=0;
        __delay_ms(250);
    }
    return;
}
