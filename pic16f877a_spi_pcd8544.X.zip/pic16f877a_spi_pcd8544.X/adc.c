
#include "adc.h"

void adc_init(void){
    PORTA=0;
    TRISA=0xFF;
    ADCON0bits.ADCS=0x00;   //Select FOSC/2
    ADCON0bits.CHS=0;       //Select AN0
    ADCON0bits.GO=0;        //Disable Conversion
    ADCON0bits.ADON=1;      //Turn On ADC
    
    ADCON1bits.ADFM=1;      //Right Justify
    ADCON1bits.ADCS2=0;     //Select FOSC/2
    ADCON1bits.PCFG=0x02;   //Select AN4:AN0
    __delay_us(100);
}

uint16_t adc_read(uint8_t channel){
    ADCON0bits.CHS=channel;
    __delay_us(100);
    GO=1;
    while(GO);  
    uint16_t result = (ADRESH<<8)+ADRESL;
    return result;
}
