/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 17, 2024, 10:00 AM
 */

#include <xc.h>
#include "config.h"
#include <stdio.h>
#include "pcd8544.h"
#include "adc.h"

#define _XTAL_FREQ  20000000UL

void main(void) {
    static uint16_t adc_value,voltage;
    static uint8_t adc_channel=0;
    uint8_t text[4];
    adc_init();
    lcd_initialize();
    PORTA=0;
    TRISA=0x0F;
    PORTB=0;
    TRISB=0x0F;
    nRBPU=0;
    lcd_fill(0);
    lcd_text_tahoma_15x16(5,0,"AN0");
    lcd_text_tahoma_15x16(53,0,"CH");
    while(1){
        if(RB0==0){
            adc_channel=0;
            lcd_text_tahoma_15x16(5,0,"AN0");
            lcd_text_tahoma_15x16(53,0,"CH");
        }
        if(RB1==0){
            adc_channel=1;
            lcd_text_tahoma_15x16(5,0,"AN1");
            lcd_text_tahoma_15x16(53,0,"CH");
        }
        if(RB2==0){
            adc_channel=2;
            lcd_text_tahoma_15x16(5,0,"AN2");
            lcd_text_tahoma_15x16(53,0,"CH");
        }
        if(RB3==0){
            adc_channel=3;
            lcd_text_tahoma_15x16(5,0,"AN3");
            lcd_text_tahoma_15x16(53,0,"CH");
        }
        
        adc_value = adc_read(adc_channel);
        sprintf(text,"%4d",adc_value);
        lcd_text_tahoma_15x16(15,2,text);
        voltage = (50*adc_value)/1023;
        sprintf(text,"%01d.%01dV",voltage/10,voltage%10);
        lcd_text_tahoma_15x16(15,4,text);
        __delay_ms(200);
    }
    return;
}
