
#include "pcd8544.h"

void lcd_character( char character){
     int i;
     static int x_count=0;
     lcd_write(LCD_D,0x00);
     for(i=0;i<5;i++){
         lcd_write(LCD_D,ASCII[character-0x20][i]);
     }
     lcd_write(LCD_D,0x00);
     x_count+=1;
     if(x_count>=12){
         x_count=0;
     }
     char_count=x_count;
}

void lcd_fill(unsigned char data){
    lcd_xy(0,0);
    for(uint16_t i=0;i<LCD_X*LCD_Y/8;i++) lcd_write(LCD_D,data);
}

void lcd_new_line(){
    int temp;
    temp=12-char_count;
    if(temp!=0){
    for(int i=0;i<temp;i++)
        lcd_character(' ');
    }
}

void lcd_xy(int8_t x, int8_t y){
    if(x<84)    lcd_write(LCD_C,0x80+x);
    if(y<6)     lcd_write(LCD_C,0x40+y);
}

void lcd_initialize(void){
    spi_init();
    TRISC0=0;
    TRISC1=0;
    CS=1;       
       
    lcd_write(LCD_C,0x21); // LCD Extended Commands
    lcd_write(LCD_C,0xB1); // SET LCD CONTRAST
    lcd_write(LCD_C,0x04); // set temp coefficient 0x04
    lcd_write(LCD_C,0x14); // LCD bias 
    lcd_write(LCD_C,0x20);
    lcd_write(LCD_C,0x0C); // LCD normal Mode
    
    /*
    lcd_write(LCD_C,0b00100001);
    lcd_write(LCD_C,0b10010000);
    lcd_write(LCD_C,0b00100000);     
    lcd_write(LCD_C,0b00001101);
    */
}

void lcd_text( char *character){
    while(*character) lcd_character(*character++);
}

void lcd_char_tahoma_15x16(int8_t x, int8_t y, uint8_t ch){
    uint16_t c=x*2;
    for(uint8_t i=0;i<30;i++){
        if(i%2) {lcd_xy(c/2,y+1); lcd_write(LCD_D,Tahoma15x16[ch-0x20][i]);}
        else {lcd_xy(c/2,y); lcd_write(LCD_D,Tahoma15x16[ch-0x20][i]);}
        c++;
    }
}

void lcd_text_tahoma_15x16(int8_t x, int8_t y, uint8_t *text){
    while(*text){
        lcd_char_tahoma_15x16(x,y,*text++);
        x+=15;
    }
}

void lcd_write( char _dc, unsigned char _data){
    D_C=_dc;
    CS=0;
    spi_send(_data);
    CS=1;
}

