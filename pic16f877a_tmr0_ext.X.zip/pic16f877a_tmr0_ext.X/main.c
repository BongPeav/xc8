/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 5, 2024, 7:43 AM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  20000000UL

uint8_t ticks_1ms=0;
uint16_t counter=0;

void __interrupt() ISR(){
    /*PORTB Interrupt On Change*/
    if(RBIE&&RBIF){
        if(RB4==0) counter+=1;
        if(RB5==0) counter-=1;
        if(RB6==0) counter=0;
        if(RB7==0) counter=2024; 
        RBIF=0;
        
    }
    /*TIMER0 Overflow Interrupt*/
    if(TMR0IE&&TMR0IF){
        ticks_1ms+=1;
        TMR0=-20;
        if(ticks_1ms>20) ticks_1ms=0;
        TMR0IF=0;
    }
}

/*Common Cathode ROM Display Data*/
const uint8_t segment[]={0x3F,0x06,0x5B,0x4F,
                         0x66,0x6D,0x7D,0x07,
                         0x7F,0x6F,0x77,0x7C,
                         0x39,0x5E,0x79,0x71};

void digit_on(uint8_t value,int8_t pin){
    /*Seven-Segment Common Driver Process*/
    PORTB=0xF0;
    PORTD=value;
    if(pin==1) RB0=1;
    if(pin==2) RB1=1;
    if(pin==3) RB2=1;
    if(pin==4) RB3=1;
}

void display_data(void){
    uint8_t third,second,one,zero;
    
    /*Seven Segment Number Process*/
    if(counter>9999) counter=0;
    third=counter/1000;
    second=(counter%1000)/100;
    one=(counter%100)/10;
    zero=counter%10;
    
    /*Multiplexing Display Process*/
    switch(ticks_1ms){
        case 0: digit_on(segment[zero],1); break;
        case 5: digit_on(segment[one],2); break;
        case 10: digit_on(segment[second],3); break;
        case 15: digit_on(segment[third],4); break;
    }
}

void main(void) {
    PORTD=0;
    PORTB=0;
    TRISD=0;
    TRISB=0xF0; //RB7:RB4 As Digital Inputs
    nRBPU=0;    //Enable PORTB Weak Pull Up
    T0CS=0;     //Select Internal instruction cycle clock (CLKO)
    PSA=0;      //Pre-scaler is assigned to the Timer0 module
    OPTION_REGbits.PS=0x07; //TMR0 Rate 1:256
    TMR0IE=1;   //Enable TIMER0 Overflow Interrupt
    RBIE=1;     //Enable PORTB Interrupt On Change
    GIE=1;      //Enable Global Interrupt
    TMR0IF=0;   //Clear TIMER0 Overflow Interrupt Flag
    RBIF=0;     //Clear PORTB Interrupt On Change Flag
    TMR0=0;     //Clear TIMER0
    
    while(1){
        display_data();
    }
    return;
}
