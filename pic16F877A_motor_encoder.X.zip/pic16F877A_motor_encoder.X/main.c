/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 19, 2024, 5:53 PM
 */

#include <xc.h>
#include "config.h"
#include "hd44780.h"
#include "adc.h"

#define _XTAL_FREQ  20000000UL
#define TMR1_ONE_MINS   572

int16_t pulse_counts = 0;
uint16_t IDX_COUNTS = 0;
uint16_t timer1_int_counts = 0;
char direction = 0;
uint8_t TMR0H = 0;

/*Fosc = 20MHz Pre-Scaler = 1:16 PWM FREQ = 1.22kHz*/
void pwm1_init(void){
    TRISC2=0;
    CCP1CONbits.CCP1M = 0x0C;
    PR2=0xFF;
    T2CONbits.T2CKPS = 2;
    T2CONbits.TMR2ON = 1;
    /*Set Duty Cycle To 0*/
    CCP1CONbits.CCP1X=0;
    CCP1CONbits.CCP1Y=0;
    CCPR1L=0;
    PIR1bits.TMR2IF = 0;
}

void pwm2_init(void){
    TRISC1 = 0;
    CCP2CONbits.CCP2M = 0x0C;
    PR2 = 0xFF;
    T2CONbits.TOUTPS = 2;
    T2CONbits.TMR2ON = 1;
    /*Set Duty Cycle To 0*/
    CCP2CONbits.CCP2X = 0;
    CCP2CONbits.CCP2Y = 0;
    CCPR2L = 0xFA;
    PIR1bits.TMR2IF = 0;
}

void pwm1_set_duty(uint8_t duty){
    //CCPR1L must less than or equal to PR2
    float f = 1023.0*duty/100; 
    uint16_t duty_cycle = (uint16_t)(f);
    CCPR1L=duty_cycle>>2;
    CCP1CONbits.CCP1X=duty_cycle&0x0002;
    CCP1CONbits.CCP1Y=duty_cycle&0x0001;    
}

void pwm2_set_duty(uint8_t duty){
    //CCPR2L must less than or equal to PR2
    float f = 1023.0*duty/100; 
    uint16_t duty_cycle = (uint16_t)(f);
    CCPR2L=duty_cycle>>2;
    CCP2CONbits.CCP2X=duty_cycle&0x0002;
    CCP2CONbits.CCP2Y=duty_cycle&0x0001;    
}

void interrupt_init(void){
    PORTB = 0;
    TRISB = 0xFF;
    PORTC = 0;
    TRISC0=0;
    //Interrupt at falling edge of RB0
    OPTION_REGbits.INTEDG = 0;
    INTCONbits.GIE = 1;
    INTCONbits.INTE = 1;
    INTCONbits.INTF = 0;   
    
    INTCONbits.RBIE = 1;
    INTCONbits.RBIF = 0;
}

void timer_init(void){
    OPTION_REGbits.T0CS = 1;
    OPTION_REGbits.T0SE = 0;
    OPTION_REGbits.PSA = 1;
    OPTION_REGbits.PS = 0;
    
    INTCONbits.TMR0IE = 1;
    TMR0=0;
    INTCONbits.TMR0IF = 0;
    
    T1CONbits.T1CKPS = 3;   //Pre-scale 1:8
    T1CONbits.TMR1CS = 0;   //Fosc/4
    T1CONbits.TMR1ON = 1;   //Timer1 ON
    INTCONbits.PEIE = 1;
    PIE1bits.TMR1IE = 1;
    PIR1bits.TMR1IF = 0;
    TMR1H=0;
    TMR1L=0;
}

void __interrupt() ISR(){
    /*Timer0 Interrupt Flag Test*/
    if(T0IF==1){
        TMR0H++;        
        T0IF=0;
    }
    /*Timer1 Interrupt Flag Test*/
    if(TMR1IF==1){
        timer1_int_counts++;
        TMR1IF=0;
    }
    /*External Interrupt At RB0*/
    if(INTF==1&&INTE==1){
        direction=~direction;
        pulse_counts=0;
        RC0 = 0;
        __delay_ms(250);
        timer1_int_counts = 0;
        TMR1H=0;
        TMR1L=0;
        TMR0=0;
        TMR0H=0;  
        RE1=1;
        RE1=0;
        INTF=0;
    }   
    if(RBIF==1){
        if(RB7==1){  while(RB6==0); while(RB6==1); pulse_counts++;}
        if(RB6==1){  while(RB7==0); while(RB7==1); pulse_counts--;}
        if(RB5==1){  IDX_COUNTS++; }
        if(RB4==1){}
        RBIF=0;
    }
}

void main(void) {
    __delay_ms(100);
    lcd_init();
    adc_init();
    pwm1_init();
    pwm2_init();
    timer_init();
    interrupt_init();
    pwm1_set_duty(3);
    lcd_clear();
    lcd_text("SPEED: ");
    lcd_xy(0,1);
    printf("Pulses:");
    while(1){    
        uint16_t adc_result = adc_read(0);
        float duty = 100.0*adc_result/1023;
        uint8_t temp = (uint8_t)(duty);
        if(direction==0){
            pwm2_set_duty(0);
            RC0=1;
            __delay_ms(500);         
            pwm1_set_duty(temp);
        }else{
            pwm1_set_duty(0);
            RC0=1;          
            __delay_ms(500);
            pwm2_set_duty(duty);
        }
        
        lcd_xy(0,2);
        printf("DUTY: %3d%c ADC: %4d ",temp,0x25,adc_result);        
        lcd_xy(0,3);
        printf("IDX: %4d  Q: %5d",IDX_COUNTS,pulse_counts);
        /*One Minute Duration*/
        if(timer1_int_counts>=TMR1_ONE_MINS){
            int16_t RPM = pulse_counts /24 ;  
            lcd_xy(8,0);
            printf(" %5d RPM ",RPM);
            lcd_xy(7,1); 
            printf("%5d",pulse_counts);
            RE1=1;
            RE1=0;
            timer1_int_counts = 0;
            TMR1H=0;
            TMR1L=0;               
            pulse_counts = 0;
        }
                       
    }
    return;
}

