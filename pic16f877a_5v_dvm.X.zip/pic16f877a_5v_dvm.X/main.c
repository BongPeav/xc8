/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 6, 2024, 9:26 AM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  20000000UL

void adc_init(void){
    PORTA=0;
    TRISA=0xFF;
    ADCON0bits.ADCS=0x00;   //Select FOSC/2
    ADCON0bits.CHS=0;       //Select AN0
    ADCON0bits.GO=0;        //Disable Conversion
    ADCON0bits.ADON=1;      //Turn On ADC
    
    ADCON1bits.ADFM=1;      //Right Justify
    ADCON1bits.ADCS2=0;     //Select FOSC/2
    ADCON1bits.PCFG=0x02;   //Select AN4:AN0
    __delay_us(100);
}

uint16_t adc_read(uint8_t channel){
    ADCON0bits.CHS=channel;
    __delay_us(100);
    GO=1;
    while(GO);  
    uint16_t result = (ADRESH<<8)+ADRESL;
    return result;
}

const uint8_t segment[]={0x3F,0x06,0x5B,0x4F,
                         0x66,0x6D,0x7D,0x07,
                         0x7F,0x6F,0x77,0x7C,
                         0x39,0x5E,0x79,0x71};

void digit_on(uint8_t value,int8_t pin){
    PORTB=0x00;
    PORTD=value;
    if(pin==1) RB0=1;
    if(pin==2) RB1=1;
    if(pin==3) RB2=1;
    if(pin==4) RB3=1;
    __delay_ms(5);
}

void main(void) {
    uint16_t adc_value=0,voltage=0;
    uint8_t volt_dec=0,volt_dot=0;
    PORTD=0;
    TRISD=0;
    adc_init();
    PORTB=0;
    TRISB=0;
    while(1){
        adc_value = adc_read(0);
        voltage = (50*adc_value)/1023;
        volt_dec=voltage/10;
        volt_dot=voltage%10;
        digit_on(segment[volt_dec]|0x80,4);
        digit_on(segment[volt_dot],3);
        digit_on(0x62,1);
    }
    return;
}


