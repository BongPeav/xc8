/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 7, 2024, 9:13 AM
 */

#include <xc.h>
#include "config.h"
#include "hd44780.h"
#include "i2c.h"

#define _XTAL_FREQ  20000000UL

const char ds1307_write = 0xD0;
const char ds1307_read  = 0xD1;

void rtc_write(uint8_t address, uint8_t data){
    i2c_start();
    i2c_write(ds1307_write);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
}

uint8_t rtc_read(uint8_t address){
    i2c_start();
    i2c_write(ds1307_write);
    i2c_write(address);
    i2c_stop();
    
    i2c_start();
    i2c_write(ds1307_read);
    uint8_t data = i2c_read(0);
    i2c_stop();
    
    return data;
}

uint8_t bcd_to_decimal(uint8_t bcd){
    uint8_t decimal = ((bcd>>4)*10) + (bcd&0x0F);
    return decimal;
}

uint8_t decimal_to_bcd(uint8_t data){
    return (((data/10)<<4)+(data%10));
}

void rtc_set(void){
    uint8_t rtc_data[]={30,45,12,1,7,3,24};
    for(char i=0;i<sizeof(rtc_data);i++)
        rtc_write(i,decimal_to_bcd(rtc_data[i]));
}

void main(void) {
    uint8_t time[3],date[3];
    lcd_init();
    i2c_init(100000);
    
    lcd_command(0x0C);
    //rtc_set();
    while(1){
        time[0]=bcd_to_decimal(rtc_read(0));
        time[1]=bcd_to_decimal(rtc_read(1));
        time[2]=bcd_to_decimal(rtc_read(2));
        lcd_xy(0,0);
        printf("TIME: %2d:%2d:%2d",time[2],time[1],time[0]);
        
        date[0]=bcd_to_decimal(rtc_read(4));
        date[1]=bcd_to_decimal(rtc_read(5));
        date[2]=bcd_to_decimal(rtc_read(6));
        lcd_xy(0,1);
        printf("DATE: 20%02d/%2d/%2d",date[2],date[1],date[0]);
        __delay_ms(500);
    }
    return;
}
