/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 10, 2024, 3:30 PM
 */


#include <xc.h>
#include "config.h"
#include "hd44780.h"
#include "i2c.h"

#define _XTAL_FREQ  20000000UL

const uint8_t PCF8574A_WRITE = 0x70;
const uint8_t PCF8574A_READ  = 0x71;

const uint8_t kb[][4]={
'1','2','3','A',
'4','5','6','B',
'7','8','9','C',
'*','0','#','D'
};

void pcf8574a_init(void){
    i2c_init(100000);
    i2c_start();
    i2c_write(PCF8574A_WRITE);
    i2c_write(0x0F);
    i2c_write(0x0F);
    i2c_stop();
}

uint8_t pcf8574a_read(){
    i2c_start();
    i2c_write(PCF8574A_READ);
    uint8_t data = i2c_read(0);
    i2c_stop();
    return data;
}

void pcf8574a_write(uint8_t data){
    i2c_start();
    i2c_write(PCF8574A_WRITE);
    i2c_write(data);
    i2c_write(data);
    i2c_stop();
}

/*
uint8_t kb_scan(void){
    uint8_t data,key=0;
    for(uint8_t i=0;i<4;i++){
        data=(1<<i);
        pcf8574a_write(data);
        __delay_ms(10);
        data=pcf8574a_read();
        data>>=4;
        if(data==0x01){key=kb[i][0]; break;}
        if(data==0x02){key=kb[i][1]; break;}
        if(data==0x04){key=kb[i][2]; break;}
        if(data==0x08){key=kb[i][3]; break;}
        if(data==0) key=0;       
    }
    return key;
}
*/

uint8_t kb_scan(void){
    uint8_t data,key=0;
    for(uint8_t i=0;i<4;i++){
        data&=~(1<<i);
        data|=0xF0;
        pcf8574a_write(data);
        __delay_ms(10);
        data=pcf8574a_read();
        data>>=4;
        if(data==0x0E){key=kb[i][0]; break;}
        if(data==0x0D){key=kb[i][1]; break;}
        if(data==0x0B){key=kb[i][2]; break;}
        if(data==0x07){key=kb[i][3]; break;}
        if(data==0) key=0;       
    }
    return key;
}

void main(void) {
    uint8_t key=0,char_count=0;
    __delay_ms(500);
    pcf8574a_init();
    lcd_init();
    lcd_text("PIC16F877A XC8");
    lcd_xy(0,1);
    lcd_text("PCF8574A KeyPad");
    __delay_ms(5000);
    lcd_clear();
    lcd_text(" PRESS ANY KEY:");
    lcd_xy(0,1);
    while(1){     
        key = kb_scan();
        if(key!=0){
            lcd_character(key);
            key=0;
            char_count++;
            __delay_ms(200);
        }       
        if(char_count>16){
            lcd_clear();
            lcd_text(" PRESS ANY KEY:");
            char_count=0;
            lcd_xy(0,1);
        }
    }
    return;
}
