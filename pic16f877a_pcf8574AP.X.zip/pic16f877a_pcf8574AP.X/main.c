/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 9, 2024, 8:43 AM
 */

#include <xc.h>
#include "config.h"
#include "hd44780.h"
#include "i2c.h"

#define _XTAL_FREQ  20000000UL

const uint8_t PCF8574A_WRITE = 0x70;
const uint8_t PCF8574A_READ  = 0x71;

void pcf8574a_init(void){
    i2c_init(100000);
    i2c_start();
    i2c_write(PCF8574A_WRITE);
    i2c_write(0xFF);
    i2c_write(0xFF);
    i2c_stop();
}

uint8_t pcf8574a_read(){
    i2c_start();
    i2c_write(PCF8574A_READ);
    uint8_t data = i2c_read(0);
    i2c_stop();
    return data;
}

void main(void) {
    uint8_t data=0,binary=0;
    __delay_ms(500);
    pcf8574a_init();
    lcd_init();
    printf("PIC16F877A XC8");
    lcd_xy(0,1);
    printf("PCF8574AP I2C");
    __delay_ms(3000);
    lcd_clear();
    
    lcd_xy(1,0);
    lcd_text("BINARY");
    lcd_xy(10,0);
    lcd_text("HEX");
    lcd_command(0x0C);
    while(1){
        data = pcf8574a_read();
        lcd_xy(0,1);
        for(int8_t i=7;i>=0;i--){
            binary = (data&(1<<i))?'1':'0';
            lcd_character(binary);
        }
        lcd_xy(10,1);
        printf("0x%02X",data);
        __delay_ms(1000);
    }
    return;
}
