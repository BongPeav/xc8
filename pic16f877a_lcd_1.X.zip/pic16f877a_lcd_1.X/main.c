/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 3, 2024, 1:47 PM
 */

#include <xc.h>
#include <stdio.h>
#include "config.h"

#define _XTAL_FREQ  20000000UL

#define RS  RD5
#define RW  RD6
#define EN  RD7
#define DP  PORTD
#define DR  TRISD

#define latch_delay() __delay_us(50)

void lcd_command(uint8_t command){
    
    DP=command>>4;
    RS=0;
    RW=0;
    EN=1;
    latch_delay();
    EN=0;
    latch_delay();
    
    DP=command&0x0F;
    RS=0;
    RW=0;
    EN=1;
    latch_delay();
    EN=0;
    latch_delay();
}

void lcd_character(uint8_t character){
    
    DP=character>>4;
    RS=1;
    RW=0;
    EN=1;
    latch_delay();
    EN=0;
    latch_delay();
    
    DP=character&0x0F;
    RS=1;
    RW=0;
    EN=1;
    latch_delay();
    EN=0;
    latch_delay();
}

void lcd_text(uint8_t *text){
    while(*text) lcd_character(*text++);
}

void lcd_xy(uint8_t x, uint8_t y){
    uint8_t line[]={0x80,0xC0};
    lcd_command(line[y]+x);
}

void lcd_init(void){
    /*Digital Output Port*/
    DP=0;
    DR=0;
    /*Disable Analog Input*/
    //ADCON1bits.PCFG=0x06;
    
    lcd_command(0x33);
    lcd_command(0x32);
    lcd_command(0x28);
    lcd_command(0x0F);
    lcd_command(0x01);
    __delay_ms(10);
    lcd_command(0x06);
    __delay_ms(10);
}

void putch(char data){
    lcd_character(data);
}

void main(void) {
    lcd_init();
    lcd_text("HELLO WORLD!");
    lcd_xy(0,1);
    lcd_text("PIC16F877A XC8");
    __delay_ms(2500);
    lcd_command(0x01);
    __delay_ms(5);
    lcd_command(0x0C);
    printf("Temperature:");
    lcd_xy(0,1);
    float temp=33.70;
    printf("%.2f%cC",temp,223);
    while(1){
        
    }
    return;
}
