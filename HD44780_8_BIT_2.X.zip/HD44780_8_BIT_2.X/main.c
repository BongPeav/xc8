/*
 * File:   main.c
 * Author: Admin
 *
 * Created on December 20, 2023, 2:18 PM
 */

#include <stdio.h>
#include <xc.h>
#include "config.h"

#define _XTAL_FREQ 8000000UL

#define RS RD0
#define EN RD1
#define CB PORTD
#define CR TRISD
#define DB PORTC
#define DR TRISC

void lcdCommand(char command){
    DB=command;
    RS=0;
    EN=1;
    __delay_us(25);
    EN=0;
    __delay_us(25);
}

void lcdData(char data){
    DB=data;
    RS=1;
    EN=1;
    __delay_us(25);
    EN=0;
    __delay_us(25);
}

void lcdString(char *myText){
    while(*myText) lcdData(*myText++);
    __delay_us(25);
}

void lcdXY(char x,char y){
    // 16x2
    char addr[]={0x80,0xC0};
    lcdCommand(addr[y-1]+x-1);
}

void lcdInit(void){
    DB=0;
    DR=0;
    CB=0;
    CR=0;
    __delay_ms(10);
    lcdCommand(0x38);
    lcdCommand(0x0C);
    lcdCommand(0x01);
    __delay_ms(5);
    lcdCommand(0x06);
    __delay_ms(5);
}
void main(void) {
    OSCCONbits.IRCF=7;
    unsigned char seconds=0,minutes=0,hours=0,days=0;
    char message[16];
    lcdInit();
    lcdString("PIC16F887 XC8");
    lcdXY(1,2);
    lcdString("LCD Programming");
    __delay_ms(2500);
    lcdCommand(0x01);
    __delay_ms(5);
    lcdXY(5,1);
    lcdString("Up Time:");
    while(1){
        if(seconds>59){seconds=0; minutes++;}
        if(minutes>59){minutes=0; hours++;}
        if(hours>23){hours=0; days++;}
        sprintf(message,"%2d - %2d:%2d:%2d",days,hours,minutes,seconds);
        lcdXY(1,2); lcdString(message);
        seconds++;
        __delay_ms(1000);
    }
    return;
}

