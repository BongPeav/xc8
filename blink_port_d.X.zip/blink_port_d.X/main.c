/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 2, 2024, 7:29 PM
 */

#include <xc.h>


// PIC16F877A Configuration Bit Settings

// 'C' source line config statements

// CONFIG
#pragma config FOSC = HS        // Oscillator Selection bits (HS oscillator)
#pragma config WDTE = OFF       // Watchdog Timer Enable bit (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable bit (PWRT disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable bit (BOR enabled)
#pragma config LVP = OFF        // Low-Voltage (Single-Supply) 
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection bit 
#pragma config WRT = OFF        // Flash Program Memory Write Enable bits 
#pragma config CP = OFF         // Flash Program Memory Code Protection bit 


#define _XTAL_FREQ  20000000

void main(void) {
    PORTD=0;
    TRISD=0;
    while(1){
        PORTD=~PORTD;
        __delay_ms(1000);       
    }
    return;
}
