/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 24, 2024, 5:57 PM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  40000000UL
#define PRESS_TIME  250

const unsigned char ssd[16]={0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,
	0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71};

uint16_t milliseconds = 0;
uint16_t press_counts = 0;
uint8_t  digit_counts = 0;

void display_data(void);

void __interrupt(high_priority) isr(void){
    /*Interrupt Flag Set every 1 milliseconds*/
    if(TMR5IF==1&&TMR5IE==1){        
        milliseconds++;        
        digit_counts++;
        if(digit_counts>=20) digit_counts=0;
        display_data();
        TMR5IF = 0;
    }
}

void display_data(void){
    uint8_t d1,d2,d3,d4;
    d1=press_counts/1000;
    d2=(press_counts%1000)/100;
    d3=(press_counts%100)/10;
    d4=press_counts%10;
    
    switch(digit_counts){
        case 0:     LATC=0; LATD=ssd[d1]; LATC0=1; break;
        case 5:     LATC=0; LATD=ssd[d2]; LATC1=1; break;
        case 10:    LATC=0; LATD=ssd[d3]; LATC2=1; break;
        case 15:    LATC=0; LATD=ssd[d4]; LATC3=1; break;       
    }
}

void main(void) {
    PORTC = 0;
    LATC = 0;
    TRISC = 0xF0;
    PORTD = 0;
    LATD = 0;
    TRISD = 0;
    PORTB = 0;
    LATB = 0;
    TRISB = 0x0F;
    INTCON2bits.nRBPU = 0;
    /*Timer5 Pre-Scaler Is 1:1*/
    T5CONbits.T5PS = 0;
    T5CONbits.TMR5ON = 1;
    
    /*Timer5 Interrupt Enabled*/
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    PIE3bits.TMR5IE = 1;
    PIR3bits.TMR5IF = 0;
    /*Timer5 Interrupt Is Priority*/
    IPR3bits.TMR5IP = 1;
    
    /* Set Period Register to 10000 (0x2710)
     * Timer 1 counts up to 10000 to and rolls down then TMR5IF is set
     * 
     */
    PR5H = 0x27;
    PR5L = 0x10;
    TMR5L = 0;
    TMR5H = 0;
    while(1){
        if(RB0==0&&milliseconds>=PRESS_TIME){
            if(press_counts>=9999) press_counts = 0;
            else press_counts++;
            milliseconds = 0;
        }
        if(RB1==0&&milliseconds>=PRESS_TIME){
            if(press_counts==0) press_counts=9999;
            else press_counts--;
            milliseconds = 0;
        }
        if(RB2==0&&milliseconds>=PRESS_TIME){
            press_counts = 0;
            milliseconds = 0;
        }
        if(RB3==0&&milliseconds>=PRESS_TIME){
            press_counts = 9999;
            milliseconds = 0;
        }
    }
    return;
}
