/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 4, 2024, 10:02 AM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  20000000UL

const uint8_t segment[]={0x3F,0x06,0x5B,0x4F,
                         0x66,0x6D,0x7D,0x07,
                         0x7F,0x6F,0x77,0x7C,
                         0x39,0x5E,0x79,0x71};

uint16_t counter=0;

void digit_on(uint8_t value,int8_t pin){
    PORTB=0xF0;
    PORTD=value;
    if(pin==1) RB0=1;
    if(pin==2) RB1=1;
    if(pin==3) RB2=1;
    if(pin==4) RB3=1;
    __delay_ms(5);
}

void __interrupt() ISR(){
    if(RBIF){
        if(RB4==0) counter+=1;
        if(RB5==0) counter-=1;
        if(RB6==0) counter=0;
        if(RB7==0) counter=2024;
        RBIF=0;
        
    }
    
}

void main(void) {
    PORTB=0x00;
    PORTD=0;
    TRISB=0xF0;
    TRISD=0;
    nRBPU=0;
    
    RBIE=1;
    GIE=1;
    RBIF=0;
    
    uint8_t third,second,one,zero;
    while(1){
        if(counter>9999) counter=0;
        third=counter/1000;
        second=(counter%1000)/100;
        one=(counter%100)/10;
        zero=counter%10;
        digit_on(segment[zero],1);
        digit_on(segment[one],2);
        digit_on(segment[second],3);
        digit_on(segment[third],4);        
    }
    return;
}
