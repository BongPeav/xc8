
#include "mcp23017_i2c.h"

/*MCP23017 I/O Functions*/
void mcp23017_write(uint8_t address, uint8_t data){
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
}

uint8_t mcp23017_read(uint8_t address){
    uint8_t data;
    
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_stop();
    
    __delay_us(100);
    i2c_start();
    i2c_write(MCP23017_R);
    data = i2c_read(0);
    i2c_stop();
    
    return data;
}

/*Character LCD Functions*/

void i2c_lcd_command(uint8_t command){
    uint8_t temp;
    temp = command&0xF0;
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<EN));
    __delay_us(25);
    mcp23017_write(LCD_PORT,temp|(ON<<LED));
    __delay_us(25);
    
    temp = command<<4;
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<EN));
    __delay_us(25);
    mcp23017_write(LCD_PORT,temp|(ON<<LED));
    __delay_us(25);
}

void i2c_lcd_character(uint8_t character){
    uint8_t temp;
    temp = character&0xF0;
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<EN)|(1<<RS));
    __delay_us(25);
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<RS));
    __delay_us(25);
    
    temp = character<<4;
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<RS)|(1<<EN));
    __delay_us(25);
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<RS));
    __delay_us(25);
}

void i2c_lcd_xy(uint8_t x, uint8_t y){
    uint8_t cursor[]={0x80,0xC0};
    i2c_lcd_command(cursor[y]+x);
}

void i2c_lcd_init(void){
    i2c_init(400000);
    mcp23017_write(LCD_DIR,0x00);
    i2c_lcd_command(0x33);
    i2c_lcd_command(0x32);
    i2c_lcd_command(0x28);
    i2c_lcd_command(0x0F);
    i2c_lcd_command(0x01);
    __delay_ms(5);
    i2c_lcd_command(0x06);
    
}

void i2c_lcd_clear(void){
    i2c_lcd_command(0x01);
    __delay_ms(5);
    i2c_lcd_command(0x0C);
}

void putch(char data){
    i2c_lcd_character(data);
}
