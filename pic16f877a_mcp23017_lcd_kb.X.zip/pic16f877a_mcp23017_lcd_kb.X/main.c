/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 12, 2024, 9:11 AM
 */

#include <xc.h>
#include "config.h"
#include "mcp23017_i2c.h"

#define _XTAL_FREQ  20000000UL

const uint8_t kb[][4]={
'1','2','3','A',
'4','5','6','B',
'7','8','9','C',
'*','0','#','D'
};

uint8_t kb_scan(void){
    uint8_t data,key_value=0;
    for(uint8_t i=0;i<4;i++){
        data&=~(1<<i);
        mcp23017_write(OLATA,data);
        __delay_ms(10);
        data = mcp23017_read(GPIOA);
        data>>=4;
        if(data==0x0E){key_value = kb[i][0]; break;}
        if(data==0x0D){key_value = kb[i][1]; break;}
        if(data==0x0B){key_value = kb[i][2]; break;}
        if(data==0x07){key_value = kb[i][3]; break;}
        if(data==0x0F) key_value = 0;
    }
    return key_value;
}

void main(void) {
    uint8_t key_value=0,press_count=0;
    i2c_lcd_init();
    ON=1;
    mcp23017_write(IODIRA,0xF0);
    mcp23017_write(GPPUA,0xF0);
    printf("PIC16F877A XC8");
    i2c_lcd_xy(0,1);
    printf("MCP23017 LCD KB");
    __delay_ms(5000);
    i2c_lcd_clear();
    printf("PRESS ANY KEY:");
    i2c_lcd_xy(0,1);
    i2c_lcd_command(0x0F);
    while(1){
        key_value = kb_scan();
        if(key_value!=0){
            i2c_lcd_character(key_value);
            key_value=0;
            press_count++;
            __delay_ms(250);
        }
        if(press_count>16){
            press_count=0;
            i2c_lcd_clear();
            printf("PRESS ANY KEY:");
            i2c_lcd_xy(0,1);
            i2c_lcd_command(0x0F);
        }
    }
    return;
}
