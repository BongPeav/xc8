/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 23, 2024, 9:33 AM
 */

#include <xc.h>
#include "config.h"
#include "lcd.h"

#define _XTAL_FREQ  40000000UL


void main(void) {
    lcd_init();
    lcd_text("8-Bit PORTB Binary:");
    LATB=0;
    PORTB=0;
    TRISB=0xFF;
    INTCON2bits.nRBPU = 0;
    uint8_t port_data = 0, old_data;
    old_data = ~port_data;
    while(1){
        port_data = PORTB;
        if(old_data!=port_data){
            lcd_xy(0,1);
            lcd_text("BINARY: ");
            
            for(int8_t i=7;i>=0;i--){
                lcd_data((port_data&(1<<i))==0?'0':'1');
            }
            lcd_xy(0,2);    printf("HexaDemical: 0x%02X",port_data);
            lcd_xy(0,3);    printf("Decimal    : %3d",port_data);
            old_data = port_data;
        }
    }
    return;
}
