/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 13, 2024, 3:23 PM
 */

#include <xc.h>
#include <stdio.h>
#include "config.h"
#include "sh1106.h"

#define _XTAL_FREQ  20000000UL

void adc_init(void){
    PORTA=0;
    TRISA=0xFF;
    ADCON0bits.ADCS=0x00;   //Select FOSC/2
    ADCON0bits.CHS=0;       //Select AN0
    ADCON0bits.GO=0;        //Disable Conversion
    ADCON0bits.ADON=1;      //Turn On ADC
    
    ADCON1bits.ADFM=1;      //Right Justify
    ADCON1bits.ADCS2=0;     //Select FOSC/2
    ADCON1bits.PCFG=0x02;   //Select AN4:AN0
    __delay_us(100);
}

uint16_t adc_read(uint8_t channel){
    ADCON0bits.CHS=channel;
    __delay_us(100);
    GO=1;
    while(GO);  
    uint16_t result = (ADRESH<<8)+ADRESL;
    return result;
}

void main(void) {
    PORTC=0;
    TRISC=0;
    uint16_t adc_value=0;
    uint16_t volt;
    char msg[10];
    adc_init();
    display_init();
    TRISA=0x0F;
    display_clear(0);
    display_text_8x16(0,0,"SH1106 I2C OLED");
    display_text_8x16(0,1,"PIC16F877A XC8");    
    display_text_8x16(0,2,"MPLABX IDE v6.15");
    display_text_8x16(20,3,"ADC Reading");
    __delay_ms(3000);
    display_clear(0);
    while(1){     
        adc_value = adc_read(0);    
        volt = (50*adc_value)/1023;
        sprintf(msg,"AN0: %4d %1d.%1dV",adc_value,volt/10,volt%10);    
        display_text_8x16(0,0,msg);
        
        adc_value = adc_read(1);    
        volt = (50*adc_value)/1023;
        sprintf(msg,"AN1: %4d %1d.%1dV",adc_value,volt/10,volt%10);     
        display_text_8x16(0,1,msg);
        
        adc_value = adc_read(2);    
        volt = (50*adc_value)/1023;
        sprintf(msg,"AN2: %4d %1d.%1dV",adc_value,volt/10,volt%10);    
        display_text_8x16(0,2,msg);
        
        adc_value = adc_read(3);    
        volt = (50*adc_value)/1023;
        sprintf(msg,"AN3: %4d %1d.%1dV",adc_value,volt/10,volt%10);  
        display_text_8x16(0,3,msg);
        
        __delay_ms(250);       
    }
    return;
}
