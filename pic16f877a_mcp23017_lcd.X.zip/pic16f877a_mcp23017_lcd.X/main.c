/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 11, 2024, 8:30 PM
 */

#include <xc.h>
#include <stdio.h>
#include "config.h"
#include "mcp23017_i2c.h"

#define _XTAL_FREQ  20000000UL

#define RS  0
#define RW  1
#define EN  2
#define LED 3

#define LCD_PORT GPIOB
#define LCD_DIR  IODIRB

uint8_t ON = 0;

void i2c_lcd_command(uint8_t command){
    uint8_t temp;
    temp = command&0xF0;
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<EN));
    __delay_us(25);
    mcp23017_write(LCD_PORT,temp|(ON<<LED));
    __delay_us(25);
    
    temp = command<<4;
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<EN));
    __delay_us(25);
    mcp23017_write(LCD_PORT,temp|(ON<<LED));
    __delay_us(25);
}

void i2c_lcd_character(uint8_t character){
    uint8_t temp;
    temp = character&0xF0;
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<EN)|(1<<RS));
    __delay_us(25);
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<RS));
    __delay_us(25);
    
    temp = character<<4;
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<RS)|(1<<EN));
    __delay_us(25);
    mcp23017_write(LCD_PORT,temp|(ON<<LED)|(1<<RS));
    __delay_us(25);
}

void i2c_lcd_xy(uint8_t x, uint8_t y){
    uint8_t cursor[]={0x80,0xC0};
    i2c_lcd_command(cursor[y]+x);
}

void i2c_lcd_init(void){
    mcp23017_write(LCD_DIR,0x00);
    i2c_lcd_command(0x33);
    i2c_lcd_command(0x32);
    i2c_lcd_command(0x28);
    i2c_lcd_command(0x0F);
    i2c_lcd_command(0x01);
    __delay_ms(5);
    i2c_lcd_command(0x06);
    
}

void i2c_lcd_clear(void){
    i2c_lcd_command(0x01);
    __delay_ms(5);
    i2c_lcd_command(0x0C);
}

void putch(char data){
    i2c_lcd_character(data);
}

void main(void) {
    uint8_t _second=0, _minute=0, _hour=0;
    uint16_t _day=0;
    i2c_init(400000);
    i2c_lcd_init();
    ON=1;
    printf("PIC16F877A XC8");
    i2c_lcd_xy(0,1);
    printf("MCP23017 I2C LCD");
    __delay_ms(5000);
    i2c_lcd_clear();
    i2c_lcd_xy(4,0);
    printf("UP TIME:");
    while(1){
        i2c_lcd_xy(0,1);
        printf("%6d  %02d:%02d:%02d",_day,_hour,_minute,_second);
        _second++;
        if(_second>59){_second=0; _minute++;}
        if(_minute>59){_minute=0; _hour++;}
        if(_hour>23)  { _hour=0; _day++;}
        __delay_ms(1000);
    }
    return;
}
