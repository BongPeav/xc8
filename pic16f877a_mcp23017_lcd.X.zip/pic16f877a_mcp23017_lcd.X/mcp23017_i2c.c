
#include "mcp23017_i2c.h"

void mcp23017_write(uint8_t address, uint8_t data){
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
}

uint8_t mcp23017_read(uint8_t address){
    uint8_t data;
    
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_stop();
    
    __delay_us(100);
    i2c_start();
    i2c_write(MCP23017_R);
    data = i2c_read(0);
    i2c_stop();
    
    return data;
}
