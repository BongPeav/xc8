/* 
 * File:   mcp23017_i2c.h
 * Author: Admin
 *
 * Created on March 11, 2024, 8:36 PM
 */

#include <xc.h>
#include "i2c.h"

#define _XTAL_FREQ  20000000UL

/*BANK0 Registers*/
#define IODIRA  0x00
#define IODIRB  0x01
#define GPPUA   0x0C
#define GPPUB   0x0D
#define GPIOA   0x12
#define GPIOB   0x13
#define OLATA   0x14
#define OLATB   0x15

const uint8_t MCP23017_W = 0x40;
const uint8_t MCP23017_R = 0x41;

void mcp23017_write(uint8_t address, uint8_t data);
uint8_t mcp23017_read(uint8_t address);