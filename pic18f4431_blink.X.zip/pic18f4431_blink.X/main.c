/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 22, 2024, 9:37 AM
 */


#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  40000000UL

void main(void) {
    PORTD = 0;
    LATD = 0;
    TRISD = 0;
    
    while(1){
        LATD = 0;
        __delay_ms(1000);
        LATD = 0xFF;
        __delay_ms(2000);
    }
    return;
}
