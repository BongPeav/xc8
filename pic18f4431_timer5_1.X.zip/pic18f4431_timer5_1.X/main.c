/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 24, 2024, 2:04 PM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  40000000UL

uint16_t milliseconds = 0;

void __interrupt(high_priority) isr(void){
    /*Interrupt Flag Set every 1 milliseconds*/
    if(TMR5IF==1&&TMR5IE==1){
        LATD7^=1;
        milliseconds++;
        if(milliseconds>999){ milliseconds=0; LATD6^=1; }
        //TMR5L = 0xF0;
        //TMR5H = 0xD8;        
        TMR5IF = 0;
    }
}

void main(void) {
    PORTD = 0;
    LATD = 0;
    TRISD = 0;
    /*Timer5 Pre-Scaler Is 1:1*/
    T5CONbits.T5PS = 0;
    T5CONbits.TMR5ON = 1;
    
    /*Timer5 Interrupt Enabled*/
    INTCONbits.GIE = 1;
    INTCONbits.PEIE = 1;
    PIE3bits.TMR5IE = 1;
    PIR3bits.TMR5IF = 0;
    /*Timer5 Interrupt Is Priority*/
    IPR3bits.TMR5IP = 1;
    
    /* Set Period Register to 10000 (0x2710)
     * Timer 1 counts up to 10000 to and rolls down then TMR5IF is set
     * 
     */
    PR5H = 0x27;
    PR5L = 0x10;
    TMR5L = 0;
    TMR5H = 0;
     
    while(1){
        
    }
    return;
}
