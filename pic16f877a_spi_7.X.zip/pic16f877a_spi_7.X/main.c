
#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  20000000UL

#define CS RC2

#define SET     RB7
#define ZERO    RB6
#define DOWN    RB5
#define UP      RB4

/*
const uint8_t segment[]={0x3F,0x06,0x5B,0x4F,
                         0x66,0x6D,0x7D,0x07,
                         0x7F,0x6F,0x77,0x7C,
                         0x39,0x5E,0x79,0x71};
*/

const uint8_t segment[]={0xC0,0xF9,0xA4,0xB0,
                         0x99,0x92,0x82,0xF8,
                         0x80,0x90,0x88,0x83,
                         0xC6,0xA1,0x86,0x8E};

void spi_init(void){
    /*SPI Mode Clock Low To High*/
    SSPCONbits.CKP=0;
    SSPSTATbits.CKE=1;
    SSPSTATbits.SMP=0;
    /*SPI Master Mode Clock = Fosc/64*/
    SSPCONbits.SSPM=2;
    /*Turn On The Module*/
    SSPCONbits.SSPEN=1;
    SSPSTATbits.BF=1;
    PORTC=0;
    TRISC=0;
    /*SPI SDI Pin Input*/
    TRISC4=1;
}

void spi_send(uint8_t data){
    SSPSTATbits.BF==1;
    SSPBUF=data;
    while(SSPSTATbits.BF==0);
    SSPSTATbits.BF==1;
}

uint8_t spi_receive(void){
    int8_t data;
    spi_send(0x00);
    data=SSPBUF;
    return data;
}

int main(void){
    int8_t counter=0;
    PORTB=0x00;
    TRISB=0xF0;
    nRBPU=0;
    spi_init();
    while(1){
        if(UP==0){        
            if(counter>=15) counter=0;
            else counter++;
            __delay_ms(250);
        }
        if(DOWN==0){
            if(counter<=0) counter=15;
            else counter--;
            __delay_ms(250);
        }
        if(ZERO==0){
            counter=0;
            __delay_ms(250);
        }
        if(SET==0){
            counter= 15;
            __delay_ms(250);
        }
        spi_send(segment[counter]);
        CS=1;
        CS=0;
    }
    return 0;
}