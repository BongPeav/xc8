/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 9, 2024, 7:48 PM
 */

#include <xc.h>
#include <stdio.h>
#include "config.h"
#include "i2c.h"

#define _XTAL_FREQ  20000000UL

#define RS  0
#define RW  1
#define EN  2
#define BL  3

const char PCF8574_W = 0x4E;
const char PCF8574_R = 0x4F;
uint8_t LED=0;

void pcf8574_send(uint8_t data){
    i2c_start();
    i2c_write(PCF8574_W);
    i2c_write(data);
    i2c_write(data);
    i2c_stop();
}

void i2c_lcd_command(uint8_t command){
    uint8_t temp;
    temp=command&0xF0;
    pcf8574_send(temp|(LED<<BL)|(1<<EN));
    __delay_us(150);
    pcf8574_send(temp|(LED<<BL));
    __delay_us(150);
    
    temp=command<<4;
    pcf8574_send(temp|(LED<<BL)|(1<<EN));
    __delay_us(150);
    pcf8574_send(temp|(LED<<BL));
    __delay_us(150);
}

void i2c_lcd_char(uint8_t ch){
    uint8_t temp;
    temp = ch&0xF0;
    pcf8574_send(temp|(LED<<BL)|(1<<EN)|(1<<RS));
    __delay_us(150);
    pcf8574_send(temp|(LED<<BL)|(1<<RS));
    __delay_us(150);
    
    temp = ch<<4;
    pcf8574_send(temp|(LED<<BL)|(1<<RS)|(1<<EN));
    __delay_us(150);
    pcf8574_send(temp|(LED<<BL)|(1<<RS));
    __delay_us(150);
}

void i2c_lcd_text(uint8_t *text){
    while(*text) i2c_lcd_char(*text++);
}

void i2c_lcd_xy(uint8_t x, uint8_t y){
    uint8_t line[]={0x80,0xC0};
    i2c_lcd_command(line[y]+x);
}

void i2c_lcd_clear(void){
    i2c_lcd_command(0x01);
    __delay_ms(5);
}

void i2c_lcd_init(void){
    i2c_init(100000);
    pcf8574_send(0x00);
    __delay_ms(10);
    i2c_lcd_command(0x33);
    i2c_lcd_command(0x32);
    i2c_lcd_command(0x28);
    i2c_lcd_command(0x0F);
    i2c_lcd_command(0x01);
    __delay_ms(5);
    i2c_lcd_command(0x06);
    __delay_ms(10);
}

uint8_t _second=0, _minute=0, _hour=0;
uint8_t lcd_text[8];

void main(void) {
    LED=1;
    __delay_ms(500);
    i2c_lcd_init();
    i2c_lcd_xy(1,0);
    i2c_lcd_text("PIC16F877A XC8");
    i2c_lcd_xy(1,1);
    i2c_lcd_text("PCF8574 I2C LCD");
    __delay_ms(5000);
    i2c_lcd_clear();
    i2c_lcd_command(0x0C);
    i2c_lcd_xy(2,0);
    i2c_lcd_text("RUNNING TIME:");
    while(1){
        sprintf(lcd_text,"%02d:%02d:%02d",_hour,_minute,_second);
        i2c_lcd_xy(4,1);
        i2c_lcd_text(lcd_text);
        _second+=1;
        if(_second>59){ _second=0; _minute++; }
        if(_minute>59){ _minute=0; _hour++; }
        if(_hour>23) _hour=0; 
        __delay_ms(1000);
    }
    return;
}
