/*
 * File:   i2c.c
 * Author: Admin
 *
 * Created on January 1, 2024, 4:09 PM
 */


#include <xc.h>
#include "i2c.h"

void i2c_wait(void){
    while(PIR1bits.SSPIF==0);
    PIR1bits.SSPIF=0;
}

void i2c_init(long baud){
    TRISC3=1;
    TRISC4=1;
    SSPCON=0x28;
    SSPSTAT=0x80;
    SSPADD=(_XTAL_FREQ/(4*baud))-1;
}

void i2c_stop(void){
    SSPCON2bits.PEN=1;
    while(PIR1bits.SSPIF==0);
    PIR1bits.SSPIF=0;
}

void i2c_start(void){
    SSPCON2bits.SEN=1;
    while(PIR1bits.SSPIF==0);
    PIR1bits.SSPIF=0;
}
void i2c_write(uint16_t data){   
    SSPBUF=data;
    i2c_wait();
    if(SSPCON2bits.ACKSTAT==1){
        i2c_stop();
    }
}

uint8_t i2c_read(char ACK){
    uint8_t temp;
    SSPCON2bits.RCEN=1;
    i2c_wait();
    temp=SSPBUF;
    if(ACK==0) SSPCON2bits.ACKDT=1;
    else       SSPCON2bits.ACKDT=0;
    SSPCON2bits.ACKEN=1;
    i2c_wait();
    return temp;
}
