/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 17, 2024, 7:22 PM
 */

#include <xc.h>
#include "config.h"
#include "hd44780.h"

#define _XTAL_FREQ  20000000UL

#define RECEIVED     RCIF == 1

void uart_init(long baud){
    TRISC6=0;
    TRISC7=1;
    
    TXSTAbits.TXEN = 1;
    
    RCSTAbits.SPEN = 1;
    RCSTAbits.CREN = 1;
    SPBRG = ((_XTAL_FREQ/baud)/64) - 1;
}

void uart_write(uint8_t data){   
    while(TXIF==0);
    TXREG = data; 
     
}

uint8_t uart_read(void){   
    while(RCIF==0);
    uint8_t data = RCREG;
    return data;
}

void uart_text(uint8_t *txt){
    while(*txt) uart_write(*txt++);
}

void main(void) {
    __delay_ms(100);
    char receive_data=0,count=0;
    uart_init(19200);
    lcd_init();
    lcd_text("PIC16F877A UART");
    lcd_command(0xC0);
    lcd_text("AND LCD EXAMPLE");
    uart_text("PIC16F877A UART AND LCD PROGRAMMING EXAMPLE"
            "\r\nUsing MPLAB X XC8 C COMPILER...\r\n");
    __delay_ms(2500);
    lcd_clear();
    lcd_text("RECEIVED DATA:");
    lcd_xy(0,1);
    while(1){
        if(RECEIVED){
            count++;
            if(count>16){
                count=0;
                lcd_clear();
                lcd_text("RECEIVED DATA");
                lcd_xy(0,1);
            }
            receive_data = uart_read();
            uart_write(receive_data);
            lcd_character(receive_data);            
        }
    }
    return;
}
