/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 3, 2024, 7:24 PM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  20000000UL

void __interrupt() ISR(){
    if(INTE&&INTF){
        RD0^=1;
        __delay_ms(250);
        INTF=0;
    }
    if(RBIE&&RBIF){
        if(RB4==0) RD4^=1;
        if(RB5==0) RD5^=1;
        if(RB6==0) RD6^=1;
        if(RB7==0) RD7^=1;
        __delay_ms(250);
        RBIF=0;
    }
}

void main(void) {
    PORTD=0;
    PORTB=0;            //PORTD As Digital Output
    TRISD=0;        
    TRISB=0xFF;         //PORTB As Digital Input
    nRBPU=0;            //Enable Weak Pull Up at PORTB
    INTEDG=0;           //External Interrupt at falling edge
    INTCONbits.INTE=1;  //Enable External Interrupt
    INTCONbits.RBIE=1;  //Enable PORTB Interrupt On Change
    INTCONbits.GIE=1;   //Enable Global Interrupt
    INTCONbits.INTF=0;  //Clear External Interrupt Flag
    INTCONbits.RBIF=0;  //Clear Interrupt On Change Flag
    
    while(1){
        RD1=0;
        RD2=0;
        RD3=0;
        __delay_ms(500);
        RD1=1;
        RD2=1;
        RD3=1;
        __delay_ms(500);
    }
    return;
}
