

#include <xc.h>
#include <stdio.h>
#include "config.h"
#include "adc.h"

#define _XTAL_FREQ  20000000UL

#define CS  RC2

#define LCD_RS  0
#define LCD_RW  1
#define LCD_EN  2
#define LCD_BL  3

__bit LED_ON = 0;

void spi_init(void){
    /*SPI Mode Clock Low To High*/
    SSPCONbits.CKP=0;
    SSPSTATbits.CKE=1;
    SSPSTATbits.SMP=0;
    /*SPI Master Mode Clock = Fosc/64*/
    SSPCONbits.SSPM=2;
    /*Turn On The Module*/
    SSPCONbits.SSPEN=1;
    SSPSTATbits.BF=1;
    PORTC=0;
    TRISC=0;
    /*SPI SDI Pin Input*/
    TRISC4=1;
}

void spi_send(uint8_t data){
    SSPSTATbits.BF==1;
    SSPBUF=data;
    while(SSPSTATbits.BF==0);
    SSPSTATbits.BF==1;
    CS=1;
    CS=0;
}

uint8_t spi_receive(void){
    int8_t data;
    spi_send(0x00);
    data=SSPBUF;
    return data;
}

/*HD44780 LCD in Command Mode*/
void spi_lcd_command(uint8_t command){
    uint8_t temp = command&0xF0;
    spi_send(temp|(LED_ON<<LCD_BL)|(1<<LCD_EN));
    __delay_us(25);
    spi_send(temp|(LED_ON<<LCD_BL));
    __delay_us(25);
    
    temp = command<<4;
    spi_send(temp|(LED_ON<<LCD_BL)|(1<<LCD_EN));
    __delay_us(25);
    spi_send(temp|(LED_ON<<LCD_BL));
    __delay_us(25);
}

/*HD44780 LCD in Data Mode*/
void spi_lcd_character(uint8_t ch){
    uint8_t temp = ch&0xF0;
    spi_send(temp|(LED_ON<<LCD_BL)|(1<<LCD_RS)|(1<<LCD_EN));
    __delay_us(25);
    spi_send(temp|(LED_ON<<LCD_BL)|(1<<LCD_RS));
    __delay_us(25);
    
    temp = ch<<4;
    spi_send(temp|(LED_ON<<LCD_BL)|(1<<LCD_RS)|(1<<LCD_EN));
    __delay_us(25);
    spi_send(temp|(LED_ON<<LCD_BL)|(1<<LCD_RS));
    __delay_us(25);
}

/*LCD Set Position*/
void spi_lcd_xy(uint8_t x, uint8_t y){
    uint8_t cursor[] = {0x80,0xC0};
    spi_lcd_command(cursor[y]+x);
}

void putch(char ch){
    spi_lcd_character(ch);
}

void spi_lcd_clear(void){
    spi_lcd_command(0x01);
    __delay_ms(5);
    spi_lcd_command(0x0C);
}

void spi_lcd_init(void){
    spi_send(0x00);
    spi_lcd_command(0x33);
    spi_lcd_command(0x32);
    spi_lcd_command(0x28);
    spi_lcd_command(0x0F);
    spi_lcd_command(0x01);
    __delay_ms(5);
    spi_lcd_command(0x06);
}

void main(void){
    uint16_t adc_result, voltage;
    PORTA=0;
    TRISA=0x07;
    spi_init();
    spi_lcd_init();
    adc_init();
    LED_ON=1;
    printf("PIC16F877A SPI");
    spi_lcd_xy(0,1);
    printf("SN74HC595N LCD");
    __delay_ms(3000);
    spi_lcd_clear();
    
    while(1){
        adc_result = adc_read(0);
        voltage = (adc_result*50)/1023;
        spi_lcd_xy(0,0);
        printf("A0:%d.%dV",voltage/10,voltage%10);
        
        adc_result = adc_read(1);
        voltage = (adc_result*50)/1023;
        spi_lcd_xy(9,0);
        printf("A1:%d.%dV",voltage/10,voltage%10);
        
        adc_result = adc_read(2);
        voltage = (adc_result*50)/1023;
        spi_lcd_xy(0,1);
        printf("A2:%d.%dV",voltage/10,voltage%10);
        
        adc_result = adc_read(3);
        voltage = (adc_result*50)/1023;
        spi_lcd_xy(9,1);
        printf("A3:%d.%dV",voltage/10,voltage%10);
        
        __delay_ms(200);
    }
}