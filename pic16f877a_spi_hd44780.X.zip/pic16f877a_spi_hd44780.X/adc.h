/* 
 * File:   adc.h
 * Author: Admin
 *
 * Created on March 16, 2024, 6:35 PM
 */

#include <xc.h>

#define _XTAL_FREQ  20000000UL

void adc_init(void);
uint16_t adc_read(uint8_t channel);