/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 4, 2024, 7:33 PM
 */

#include <xc.h>
#include "config.h"

void delay_ms(uint16_t counter){
    while(counter>0){
        counter--;
        while(T0IF==0);
        T0IF=0;
        TMR0=-19;
    }
}

void main(void) {
    PORTD=0;
    TRISD=0;
    T0CS=0;     //Select Internal instruction cycle clock (CLKO)
    PSA=0;      //Pre-scaler is assigned to the Timer0 module
    OPTION_REGbits.PS=0x07; //TMR0 Rate 1:256
    TMR0=0;
    while(1){
        PORTD=~PORTD;
        delay_ms(500);
    }
    return;
}
