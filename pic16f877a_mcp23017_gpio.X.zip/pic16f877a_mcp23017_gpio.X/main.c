/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 10, 2024, 7:38 PM
 */

#include <xc.h>
#include "config.h"
#include "i2c.h"

#define _XTAL_FREQ  20000000UL

/*BANK0 Registers*/
#define IODIRA  0x00
#define IODIRB  0x01
#define GPPUA   0x0C
#define GPPUB   0x0D
#define GPIOA   0x12
#define GPIOB   0x13
#define OLATA   0x14
#define OLATB   0x15

const uint8_t MCP23017_W = 0x40;
const uint8_t MCP23017_R = 0x41;

void mcp23017_write(uint8_t address, uint8_t data){
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
}

uint8_t mcp23017_read(uint8_t address){
    uint8_t data;
    
    i2c_start();
    i2c_write(MCP23017_W);
    i2c_write(address);
    i2c_stop();
    
    __delay_us(100);
    i2c_start();
    i2c_write(MCP23017_R);
    data = i2c_read(0);
    i2c_stop();
    
    return data;
}

void main(void) {
    __delay_ms(10);
    uint8_t data;
    i2c_init(400000);
    
    mcp23017_write(IODIRA,0xFF);    //GPA AS INPUT
    mcp23017_write(IODIRB,0x00);    //GPB AS OUTPUT
    mcp23017_write(GPPUA,0xFF);     //GPA PULL UP ENABLE
    while(1){
        data = mcp23017_read(GPIOA);    //READ GPA
        __delay_ms(10);
        mcp23017_write(GPIOB,data);     //WRITE TO GPB
        __delay_ms(10);
    }
    return;
}
