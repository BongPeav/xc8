/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 6, 2024, 2:18 PM
 */

#include <xc.h>
#include "config.h"
#include "hd44780.h"
#define _XTAL_FREQ  20000000UL

void adc_init(void){
    PORTA=0;
    TRISA=0xFF;
    ADCON0bits.ADCS=0x00;   //Select FOSC/2
    ADCON0bits.CHS=0;       //Select AN0
    ADCON0bits.GO=0;        //Disable Conversion
    ADCON0bits.ADON=1;      //Turn On ADC
    
    ADCON1bits.ADFM=1;      //Right Justify
    ADCON1bits.ADCS2=0;     //Select FOSC/2
    ADCON1bits.PCFG=0x02;   //Select AN4:AN0
    __delay_us(100);
}

uint16_t adc_read(uint8_t channel){
    ADCON0bits.CHS=channel;
    __delay_us(100);
    GO=1;
    while(GO);  
    uint16_t result = (ADRESH<<8)+ADRESL;
    return result;
}

void main(void) {
    uint16_t adc_value=0;
    uint8_t volt_d, volt_f;
    lcd_init();
    adc_init();
    printf("PIC16F877A XC8");
    lcd_xy(0,1);
    printf("ADC LCD Example");
    __delay_ms(2500);
    lcd_clear();
    lcd_command(0x0C);
    while(1){
        adc_value = adc_read(0);
        volt_d=(5*adc_value)/1023;
        volt_f=(50*adc_value)/1023;
        volt_f%=10;
        lcd_xy(0,0);
        printf("AN0: %4d %1d.%1dV",adc_value,volt_d,volt_f);
        
        adc_value = adc_read(1);
        volt_d=(5*adc_value)/1023;
        volt_f=(50*adc_value)/1023;
        volt_f%=10;
        lcd_xy(0,1);
        printf("AN1: %4d %1d.%1dV",adc_value,volt_d,volt_f);
        __delay_ms(500);
    }
    return;
}


