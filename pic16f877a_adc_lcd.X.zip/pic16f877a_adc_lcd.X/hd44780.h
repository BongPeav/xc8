/* 
 * File:   hd44780.h
 * Author: Admin
 *
 * Created on March 3, 2024, 6:11 PM
 */

#include <xc.h>
#include <stdio.h>

#define _XTAL_FREQ  20000000UL

#define RS  RE0
#define RW  RE1
#define EN  RE2
#define CP  PORTE
#define CR  TRISE
#define DP  PORTD
#define DR  TRISD

#define latch_delay() __delay_us(50)

void lcd_command(uint8_t command);
void lcd_character(uint8_t character);
void lcd_text(uint8_t *text);
void lcd_xy(uint8_t x, uint8_t y);
void lcd_init(void);
void putch(char data);
void lcd_clear(void);
