/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 16, 2024, 4:21 PM
 */


#include <xc.h>
#include "config.h"
#include "hd44780.h"

#define _XTAL_FREQ  20e6

void ee_command(void){
    EECON2=0x55;
    EECON2=0xAA;
    EECON1bits.WR=1;
    EECON1bits.WREN=1;
}

uint16_t flash_read(uint16_t address){
    uint16_t flash_data;
    EEADRH=address>>8;
    EEADR=address&0x00FF;
    EECON1bits.EEPGD=1;
    EECON1bits.RD=1;
    ee_command();
    flash_data = (EEDATH<<8) + EEDATA;
    return flash_data;
}


void flash_write(uint16_t address){
    uint16_t data[4]={0x0FF0,0x0A55,0x0DAA,0x01D0};       
   
    for(uint8_t i=0;i<4;i++){
        EEADR=address&0x00FF;
        EEADRH=address>>8;
        
        EEDATH = data[i]>>8;       
        EEDATA = data[i]&0x00FF;
        EECON1bits.EEPGD = 1;
        EECON1bits.WREN = 1;
        
        EECON2 = 0x55;
        EECON2 = 0xAA;
        EECON1bits.WR = 1;
        while(EECON1bits.WR);       
        
        EECON1bits.WREN = 0;       
        address++;       
    }
}

void main(void) {
    __delay_ms(100);
    lcd_init();
    uint16_t memory_data[4];
    flash_write(0x1000);
    printf(" 2 Bytes Flash:");
    lcd_xy(0,1);
    for(uint8_t i=0;i<4;i++){
        memory_data[i] = flash_read(0x1000+i);
        printf("%04X",memory_data[i]);
    }
    
    while(1){
        
    }
    return;
}
