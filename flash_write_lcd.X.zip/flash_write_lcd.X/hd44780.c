
#include "hd44780.h"

void lcd_command(uint8_t command){
    
    DP=command>>4;
    RS=0;
    RW=0;
    EN=1;
    latch_delay();
    EN=0;
    latch_delay();
    
    DP=command&0x0F;
    EN=1;
    latch_delay();
    EN=0;
    latch_delay();
}

void lcd_character(uint8_t character){
    
    DP=character>>4;
    RS=1;
    RW=0;
    EN=1;
    latch_delay();
    EN=0;
    latch_delay();
    
    DP=character&0x0F;
    EN=1;
    latch_delay();
    EN=0;
    latch_delay();
}

void lcd_text(uint8_t *text){
    while(*text) lcd_character(*text++);
}

void lcd_xy(uint8_t x, uint8_t y){
    uint8_t line[]={0x80,0xC0};
    lcd_command(line[y]+x);
}

void lcd_init(void){
    /*Digital Output Port*/
    CP=0;
    CR=0;
    DP=0;
    DR=0;
    /*Disable Analog Input*/
    ADCON1bits.PCFG=0x06;
    
    lcd_command(0x33);
    lcd_command(0x32);
    lcd_command(0x28);
    lcd_command(0x0F);
    lcd_command(0x01);
    __delay_ms(10);
    lcd_command(0x06);
    __delay_ms(10);
}

void putch(char data){
    lcd_character(data);
}

void lcd_clear(void){
    lcd_command(0x01);
    __delay_ms(10);
    lcd_command(0x0C);
}