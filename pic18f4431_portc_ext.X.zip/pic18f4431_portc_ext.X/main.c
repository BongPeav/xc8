/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 23, 2024, 8:00 AM
 */

#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  40000000UL

void __interrupt(high_priority) _isr(void){
    /*External Interrupt 0*/
    if(INT0IF==1&&INT0IE==1){
        LATD0^=1;
        INT0IF=0;
    }
    /*External Interrupt 1*/
    if(INT1IF==1&&INT1IE==1){
        LATD1^=1;
        INT1IF=0;
    }
    /*External Interrupt 2*/
    if(INT2IF==1&&INT2IE==1){
        LATD2^=1;
        INT2IF=0;
    }
}

void main(void) {
    /*PORTD AS OUTPUT, RC5:RC3 AS INPUT*/
    LATD = 0;
    PORTD = 0;
    TRISD = 0;
    PORTC = 0;
    LATC = 0;
    TRISC3 = 1;
    TRISC4 = 1;
    TRISC5 = 1;
    /*
     * Enable PORTC RC5:RC3 External Interrupt Sources,
     * External Interrupts At Falling Edge By Default
     * External Interrupts Are High Priority By Default
     */
    INTCONbits.GIE = 1;
    INTCONbits.INT0IE = 1;
    INTCONbits.INT0IF = 0;
    INTCON3bits.INT1IE = 1;
    INTCON3bits.INT1IF = 0;
    INTCON3bits.INT2IE = 1;
    INTCON3bits.INT2IF = 0;
    while(1){
        LATD3^=1;
        __delay_ms(500);
    }
    return;
}
