/*
 * File:   main.c
 * Author: Admin
 *
 * Created on March 8, 2024, 1:42 PM
 */

#include <xc.h>
#include <string.h>
#include "config.h"
#include "hd44780.h"
#include "i2c.h"

#define _XTAL_FREQ  20000000UL

const char WRITE = 0xA0;
const char READ = 0xA1;

void send_24c16(uint8_t address, uint8_t data){
    i2c_start();
    i2c_write(WRITE);
    i2c_write(address);
    i2c_write(data);
    i2c_stop();
    __delay_ms(10);
}

void send_buffer(uint8_t address, uint8_t *data){
    i2c_start();
    i2c_write(WRITE);
    i2c_write(address);
    for(uint8_t i=0;i<strlen(data);i++){
        i2c_write(data[i]);
        __delay_ms(10);
    }
    i2c_stop();
    __delay_ms(10);
}

uint8_t receive_24c16(uint8_t address){
    i2c_start();
    i2c_write(WRITE);
    i2c_write(address);
    i2c_stop();
    //__delay_ms(10);
    
    uint8_t data;
    i2c_start();
    i2c_write(READ);
    data = i2c_read(0);
    i2c_stop();
    //__delay_ms(10);
    return data;
}

uint8_t buffer[16];
void read_buffer(uint8_t address){
    
    for(uint8_t i=0;i<16;i++){
        buffer[i]=receive_24c16(address+i);
    }
}

void main(void) {
    __delay_ms(500);
    i2c_init(100000);
    lcd_init();
    
    send_buffer(0,"PIC16F877A XC8  ");
    read_buffer(0x00); 
    lcd_text(buffer);
    
    send_buffer(16,"24C16 I2C EEPROM");
    read_buffer(16); 
    lcd_xy(0,1);
    lcd_text(buffer);
    while(1){
        
    }
    return;
}
