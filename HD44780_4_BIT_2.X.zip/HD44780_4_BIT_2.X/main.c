/*
 * File:   main.c
 * Author: Admin
 *
 * Created on December 20, 2023, 7:36 PM
 * HD44780 8-BIT LCD WITH PIC16F887
 * MPLABX IDE v6.15 AND XC8 2.36
 */

#include <stdio.h>
#include <xc.h>
#include "config.h"

#define _XTAL_FREQ  8000000UL

#define DB  PORTD
#define DR  TRISD
#define RS  RD0
#define EN  RD1

/*LCD Command RS=0*/
void lcdCommand(char command){
    DB=command&0xF0;
    RS=0;
    EN=1;
    __delay_us(25);
    EN=0;
    __delay_us(25);
    
    DB=command<<4;
    RS=0;
    EN=1;
    __delay_us(25);
    EN=0;
    __delay_us(250);
}

/*LCD Data RS=1*/
void lcdData(char data){
    DB=data&0xF0;
    RS=1;
    EN=1;
    __delay_us(25);
    EN=0;
    __delay_us(25);
    
    DB=data<<4;
    RS=1;
    EN=1;
    __delay_us(25);
    EN=0;
    __delay_us(250);
}

void lcdXY(char x, char y){
    // 16x2
    char addr[]={0x80,0xC0};
    lcdCommand(addr[y-1]+x-1);
}

void lcdString(char *str){
    while(*str) lcdData(*str++);
    __delay_us(25);
}

void lcdInit(void){
    DB=0;
    DR=0;
    __delay_ms(10);
    lcdCommand(0x33);
    lcdCommand(0x32);
    lcdCommand(0x28);
    lcdCommand(0x0C);
    lcdCommand(0x01);
    __delay_ms(5);
    lcdCommand(0x06);
    __delay_us(100);
}

void main(void) {
    char seconds=0,minutes=0,hours=0;
    int days=0;
    char message[16];
    /*Internal 8MHz RC OSC*/
    OSCCONbits.IRCF=7;
    lcdInit();
    lcdString("PIC16F887 4-BIT");
    lcdXY(3,2);
    lcdString("HD44780 LCD");
    __delay_ms(2500);
    lcdCommand(0x01);
    __delay_ms(5);
    lcdXY(4,1);
    lcdString("Started Up:");     
    while(1){
        if(seconds>59){seconds=0; minutes++;}
        if(minutes>59){minutes=0; hours++;}
        if(hours>23){hours=0; days++;}
        sprintf(message,"%4d - %2d:%2d:%2d",days,hours,minutes,seconds);
        lcdXY(1,2); lcdString(message);
        seconds++;      
        __delay_ms(1000);
    }
    return;
}
