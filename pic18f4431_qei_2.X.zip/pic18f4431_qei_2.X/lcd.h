/* 
 * File:   lcd.h
 * Author: Admin
 *
 * Created on March 31, 2024, 4:31 PM
 */

#include <xc.h>
#include <stdio.h>
#include "config.h"

#define _XTAL_FREQ  40000000UL

#define RS  LATD0
#define EN  LATD1
#define DB  LATD
#define DR  TRISD

void lcd_enable(char mode);
void lcd_command(uint8_t command);
void lcd_data(uint8_t data);
void lcd_text(uint8_t *text);
void lcd_clear(void);
void putch(char ch);
void lcd_xy(uint8_t x, uint8_t y);
void lcd_init(void);