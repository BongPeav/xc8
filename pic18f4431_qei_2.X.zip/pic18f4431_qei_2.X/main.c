/*
 * File:   main.c
 * Author: Admin
 *
 * Created on April 24, 2024, 9:36 AM
 */

#include <xc.h>
#include <string.h>
#include "config.h"
#include "lcd.h"

#define _XTAL_FREQ  40000000UL

int16_t count = 0;
int16_t qei_counter = 0;
uint16_t days = 0;
uint8_t seconds = 0, minutes=0, hours=0,old_seconds=0xFF;

void __interrupt(high_priority) _isr(void){
    if(TMR5IF==1&&TMR5IE==1){
        count++;    
        if(count>=153) {count=0; seconds++;}
        TMR5IF=0;
    }
}

void main(void) {
    lcd_init();
    lcd_clear();
      
    /*QEI Enable, with x2, and counter reset at maximum counts*/
    QEICONbits.QEIM = 0x02;
    /*Enable Noise Filter For QEA, QEB, INDX with 1:128*/
    DFLTCONbits.FLT3EN = 1;
    DFLTCONbits.FLT2EN = 1;
    DFLTCONbits.FLT1EN = 1;
    DFLTCONbits.FLTCK = 0x06;
    
    /*Capture Register CAP3BUF maximum value*/
    CAP3BUFH = 0xFF;
    CAP3BUFL = 0xFF;
    CAP2BUFH = 0;
    CAP2BUFL = 0;
    
    /*Timer 1:1 pre-scaler, interrupt enable, interrupt high priority*/
    T5CONbits.TMR5ON = 1;
    INTCONbits.GIE=1;
    INTCONbits.PEIE=1;
    IPR3bits.TMR5IP=1;
    PIE3bits.TMR5IE=1;
    PIR3bits.TMR5IF=0;
    
    while(1){
        lcd_xy(0,1);
        printf("Direction: %s",QEICONbits.UPDOWN==1?"FORWARD":"REVERSE");
        /*One Minute Period*/
        if(seconds>=60){
            qei_counter = (CAP2BUFH<<8) + CAP2BUFL;
            lcd_xy(0,2);
            printf("Pulse Counts:%5d",qei_counter);
            int16_t rpm = qei_counter/48;
            lcd_xy(0,3);
            printf("Speed: %5d RPM",rpm);                        
            CAP2BUFH = 0;
            CAP2BUFL = 0;
            seconds=0;
            rpm=0;
            minutes++;
            if(minutes>=60){ minutes=0; hours++;}
        }        
        if(seconds!=old_seconds){
            lcd_xy(0,0);
            printf("Times: %4d %02d:%02d:%02d",days,hours,minutes,seconds);
        }
        old_seconds = seconds;
    }
    return;
}
